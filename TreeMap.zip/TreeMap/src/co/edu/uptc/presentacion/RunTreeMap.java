package co.edu.uptc.presentacion;

public class RunTreeMap {
    public static void main(String[] args) {
        new Console().menu();

    }


}
